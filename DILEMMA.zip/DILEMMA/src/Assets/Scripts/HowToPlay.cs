﻿using UnityEngine;
using System.Collections;

namespace Assets.Scripts
{
    public class HowToPlay : MonoBehaviour
    {

        public void OnClick()
        {
            Application.LoadLevel("HowToPlay");
        }
    }
    
}

