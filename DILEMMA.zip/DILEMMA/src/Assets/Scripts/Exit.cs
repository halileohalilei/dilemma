﻿using UnityEngine;
using System.Collections;

namespace Assets.Scripts
{
    public class Exit : MonoBehaviour
    {

        public void OnClick()
        {
            Application.Quit();
        }
    }

}

